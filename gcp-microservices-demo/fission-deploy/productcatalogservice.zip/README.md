# productcatalogservice
Provides the list of products from a JSON file and ability to search products and get individual products.

Archive these files:
```
zip -r productcatalogservice.zip .
```