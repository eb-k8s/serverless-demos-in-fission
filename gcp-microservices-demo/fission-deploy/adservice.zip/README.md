# adservice
Provides text ads based on given context words.

Archive these files:
```
zip -r adservice.zip .
```