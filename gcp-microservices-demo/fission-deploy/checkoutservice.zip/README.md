# checkoutservice
Retrieves user cart, prepares order and orchestrates the payment, shipping and the email notification.

Archive these files:
```
zip -r checkoutservice.zip .
```