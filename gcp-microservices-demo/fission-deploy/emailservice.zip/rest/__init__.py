from .rest import *

emailservice = DummyEmailService()